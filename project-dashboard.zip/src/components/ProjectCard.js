import { Card, CardContent, Typography, LinearProgress, AvatarGroup, Avatar } from "@mui/material";

const ProjectCard = ({ project }) => {
  return (
    <Card sx={{ width: 300, m: 2 }}>
      <CardContent>
        <Typography variant="h6">{project.title}</Typography>
        <Typography variant="subtitle2" color="text.secondary">
          {project.category}
        </Typography>
        <LinearProgress
          variant="determinate"
          value={project.progress}
          sx={{ mt: 1, mb: 2 }}
          color={project.status === "Blocked" ? "error" : "primary"}
        />
        <AvatarGroup max={4}>
          {project.team.map((member, index) => (
            <Avatar key={index} src={member.avatar} />
          ))}
        </AvatarGroup>
        <Typography variant="body2" color={project.status === "Blocked" ? "error" : "success"}>
          {project.status}
        </Typography>
      </CardContent>
    </Card>
  );
};

export default ProjectCard;

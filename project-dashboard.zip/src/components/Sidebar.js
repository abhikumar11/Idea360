import { List, ListItem, ListItemText, Drawer } from "@mui/material";

const Sidebar = () => {
  return (
    <Drawer variant="permanent" anchor="left">
      <List>
        {["Project List", "Teams", "Tasks", "Reports", "Settings"].map((text) => (
          <ListItem button key={text}>
            <ListItemText primary={text} />
          </ListItem>
        ))}
      </List>
    </Drawer>
  );
};

export default Sidebar;

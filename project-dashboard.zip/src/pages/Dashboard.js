import { Container, Grid } from "@mui/material";
import Sidebar from "../components/Sidebar";
import ProjectCard from "../components/ProjectCard";
import AIInsights from "../components/AIInsights";
import TeamAvailability from "../components/TeamAvailability";

const Dashboard = () => {
  const projects = [
    { title: "AI-Powered Search", category: "E-Commerce", progress: 80, status: "On-Track", team: [{ avatar: "https://i.pravatar.cc/300" }] },
    { title: "User Authentication", category: "Security", progress: 50, status: "At-Risk", team: [{ avatar: "https://i.pravatar.cc/301" }] },
    { title: "Payment Gateway", category: "Finance", progress: 30, status: "Blocked", team: [{ avatar: "https://i.pravatar.cc/302" }] }
  ];

  const aiInsights = ["Potential delay detected", "Backend integration ahead of schedule", "New team velocity metrics available"];
  const teams = [{ name: "Development", available: 3, total: 5 }, { name: "Design", available: 2, total: 3 }];

  return (
    <Grid container>
      <Grid item xs={2}><Sidebar /></Grid>
      <Grid item xs={10}>
        <Container>
          <Grid container spacing={2}>
            {projects.map((project, index) => (
              <Grid item key={index}>
                <ProjectCard project={project} />
              </Grid>
            ))}
          </Grid>
          <AIInsights insights={aiInsights} />
          <TeamAvailability teams={teams} />
        </Container>
      </Grid>
    </Grid>
  );
};

export default Dashboard;
